# Budget Pulse

A standalone personal finance tracker and investment dashboard that runs entirely in your browser. No server, no account, no data leaves your machine.

**One HTML file. Open it. Done.**

![Budget Pulse](https://img.shields.io/badge/zero-dependencies-4ade80) ![Budget Pulse](https://img.shields.io/badge/100%25-client--side-38bdf8) ![Budget Pulse](https://img.shields.io/badge/dark-theme-0b1120)

## Features

### Spending
- Upload **Amex** (.xls), **BMO Chequing** (.csv), and **BMO Mastercard** (.csv) statements
- Auto-categorizes 400+ transaction types with customizable rules
- Expense breakdown with click-to-expand category drill-down
- Top 10 merchants (excluding rent cheques and e-transfers)
- Search and filter by date, account, type, category, description
- Create, edit, and delete categories on the fly

### Budget
- Set monthly income and expense targets per category
- Per-month overrides for seasonal spending (e.g. higher gifts in December)
- Visual progress bars: green (under), yellow (approaching), red (over)

### Forecast
- 12-month year-end forecast with actual vs projected
- Editable future months — override any month's income/expenses/investments
- KPIs: forecast income, expenses, invested, net, and retention rate

### Investments
- Portfolio dashboard across multiple brokerage accounts (TD, Wealthsimple, etc.)
- **Live stock prices** via Finnhub API (free tier, 60 calls/min)
- **Live FX rate** (USD/CAD) via ExchangeRate-API
- Auto-refresh every 60 seconds while the page is open
- Portfolio value chart built from price snapshots over time
- **S&P 500 overlay** (SPY) for benchmark comparison
- Daily movers: which stocks are driving today's change
- Add/remove positions, update account values manually
- Interactive hover tooltip on chart with exact values and % change

### Design
- Dark theme with Outfit + JetBrains Mono fonts
- 6 tabs: Overview, Budget, Transactions, Investments, Rules, Insights
- All data stored in browser localStorage — nothing leaves your machine

## Quick Start

1. **Download** `budget_pulse_template.html`
2. **Open** it in Chrome, Edge, or Firefox
3. **Upload** your bank/credit card statements (Amex .xls, BMO .csv)
4. Transactions auto-categorize — tweak any category by clicking it

### Investment Setup

1. Go to the **Investments** tab
2. Click **⚙** and enter your free [Finnhub API key](https://finnhub.io/register) (30 seconds to sign up)
3. Use **➕ Add Position** to enter your holdings (symbol, shares, price, cost basis)
4. Click **↻ Refresh Live Prices** — prices update automatically every 60 seconds

## Supported Statement Formats

| Source | Format | Auto-detected by |
|--------|--------|-----------------|
| Amex (Cobalt, Bonvoy, etc.) | .xls (YTD Summary export) | `Date` + `Amount` columns |
| BMO Chequing | .csv | `First Bank Card` + `Transaction Type` columns |
| BMO Mastercard | .csv | `Item #` + `Card #` + `Transaction Date` columns |

Don't see your bank? Open an issue — adding new parsers is straightforward.

## How Data Works

Everything lives in `localStorage` under `bp7-*` keys:

| Key | Contents |
|-----|----------|
| `bp7-tx` | All transactions |
| `bp7-hold` | Investment holdings + prices |
| `bp7-rules` | Custom category rules |
| `bp7-cats` | Custom categories + colors |
| `bp7-bud` | Monthly budget targets |
| `bp7-mbud` | Per-month budget overrides |
| `bp7-fc` | Forecast month overrides |
| `bp7-fhkey` | Finnhub API key |
| `bp7-snap` | Portfolio value snapshots (for chart) |

**To reset everything:** open browser console and run `localStorage.clear()`, then refresh.

**To export your data:** open console and run `JSON.stringify(localStorage)` — copy the output.

## Tech Stack

- Vanilla JavaScript (no frameworks)
- [Papa Parse](https://www.papaparse.com/) for CSV parsing
- [SheetJS](https://sheetjs.com/) for Excel (.xls) parsing
- [Finnhub API](https://finnhub.io/) for live stock quotes
- [ExchangeRate-API](https://www.exchangerate-api.com/) for FX rates
- SVG for charts (no charting library)

## License

MIT — use it however you want.
